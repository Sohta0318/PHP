﻿<?php
// 配列$colorsにred,blue,yellowを格納し、
// buleを出力してください。
$color = array("red","blue", "yellow");
echo $color[1];
?>