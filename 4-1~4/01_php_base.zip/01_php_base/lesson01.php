﻿<?php
// 「Hello world.」という文字列を
// 変数に代入して出力してください。
$test = "Hello world.";
echo $test;
?>