<?php 
$connection = mysqli_connect('localhost', 'root','','cafe');
if(!$connection){
die('Failed to connect');
}
?>