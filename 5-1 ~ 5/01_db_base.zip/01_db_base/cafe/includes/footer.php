<footer>
  <div id="make_foot">
    <div>
      <h3 class="footer_title">企業情報</h3>
      <ul class="footer_link">
        <li><a href="">ご利用方法</a></li>
        <li><a href="">ニュースルーム</a></li>
        <li><a href="">株主・投資家のみなさまへ</a></li>
        <li><a href="">XXXXXXXXXXXXXXX</a></li>
        <li><a href="">XXXXXXXXXXXXXXX</a></li>
        <li><a href="">XXXXXXXXXXXXXXX</a></li>
        <li><a href="">採用情報</a></li>
      </ul>
    </div>
    <div>
      <h3 class="footer_title">コミュニティ</h3>
      <ul class="footer_link">
        <li><a href="">ダイバーシティ</a></li>
        <li><a href="">アクセシビリティ対応</a></li>
        <li><a href="">お友達を招待</a></li>
        <li><a href="">XXXXXXXXXXXXXXX</a></li>
        <li><a href="">XXXXXXXXXXXXXXX</a></li>
      </ul>
    </div>
    <div>
      <h3 class="footer_title">ホスト</h3>
      <ul class="footer_link">
        <li><a href="">XXXXXXXXXXXXXXX</a></li>
        <li><a href="">XXXXXXXXXXXXXXX</a></li>
        <li><a href="">XXXXXXXXXXXXXXX</a></li>
      </ul>
    </div>
    <div>
      <h3 class="footer_title">サポート</h3>
      <ul class="footer_link">
        <li><a href="">新型コロナウイルスに対する取り組み</a></li>
        <li><a href="">ヘルプセンター</a></li>
        <li><a href="">キャンセルオプション</a></li>
        <li><a href="">コミュニティサポート</a></li>
      </ul>
    </div>
  </div>
  <hr>
  <div id="copy">
    <p>このサイトの素材は全て著作権フリーのものを使用しています。</p>
    <p>プライバシーポリシー 利用規約 サイトマップ 企業情報</p>
    <p>&copy; 2021- LiNew, Inc. All rights reserved.</p>
  </div>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</body>

</html>